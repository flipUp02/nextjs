import { Test1 } from './test1';

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-24">
      <Test1 />
    </main>
  );
}
