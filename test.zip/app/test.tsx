'use client';

export const Test = ({ text }: { text: string }) => {
  return <div>{text}</div>;
};
