'use client';

import { Test } from './test';

export const Test1 = () => {
  return <Test text="أضف" />;
};
